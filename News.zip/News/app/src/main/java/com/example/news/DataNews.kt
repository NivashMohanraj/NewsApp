package com.example.news

class DataNews {
}