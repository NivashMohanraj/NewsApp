package com.example.news.models

data class Source(
    val id: Any,
    val name: String
)